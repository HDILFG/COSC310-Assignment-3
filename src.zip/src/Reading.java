public class Reading implements Answers{

    @Override
    public String like(){
        return "I love reading!";
    }

    @Override
    public String knowAbout() {
        return "Reading is a good way for us to gain knowledge and enrich our experience.";
    }

    @Override
    public String habit() {
        return "I read for half an hour every day, which helps me develop good reading habits.";

    }
}