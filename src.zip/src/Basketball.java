public class Basketball implements Answers{

    @Override
    public String like() {
        return "I love playing basketball!";
    }

    @Override
    public String knowAbout() {
        return "Playing basketball is a good way to exercise.";
    }

    @Override
    public String habit() {
        return "Don't forget to warm up before playing basketball!";
    }

}