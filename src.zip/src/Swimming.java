public class Swimming implements Answers{

    @Override
    public String like() {
        return "I love swimming!";
    }

    @Override
    public String knowAbout() {
        return "Swimming is a very active sport. The muscles of the whole body will be practiced during swimming.";
    }

    @Override
    public String habit() {
        return "Don't forget to warm up before playing basketball!";
    }
}