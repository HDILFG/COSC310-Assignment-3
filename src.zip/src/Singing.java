public class Singing implements Answers{

    @Override
    public String like() {
        return "I love singing!";
    }

    @Override
    public String knowAbout() {
        return "Singing makes me relax and get rid of fatigue.";
    }

    @Override
    public String habit() {
        return "I loving I like to record my songs and post them on social platforms.";
    }
}
