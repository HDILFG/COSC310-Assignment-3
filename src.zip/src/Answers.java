public interface Answers {

    String like();

    String knowAbout();

    String habit();
}


