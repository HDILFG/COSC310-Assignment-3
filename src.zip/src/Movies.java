public class Movies implements Answers{
    @Override
    public String like() {
        return "I love watching movies!";
    }

    @Override
    public String knowAbout() {
        return "Watching movies is a good way to help us relax.";
    }

    @Override
    public String habit() {
        return "I like watching action movies and romance movies, hope you will like it too.";
    }
}