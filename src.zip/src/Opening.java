public class Opening {

    public void sayHi(){
        System.out.println("Hello, I'm Mike. Nice to meet you.");
    }
}