public class Cooking implements Answers{
    @Override
    public String like() {
        return "I loving cooking!";
    }

    @Override
    public String knowAbout() {
        return "Cooking by yourself is a very fulfilling thing.";
    }

    @Override
    public String habit() {
        return "I will cook by myself on weekends.";

    }
}